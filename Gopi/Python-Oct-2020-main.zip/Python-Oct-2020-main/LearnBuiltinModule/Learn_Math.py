import math

# 5! => 5 * 4 * 3 * 2 * 1
print(math.factorial(5))

print(math.sqrt(9))

print(math.sin(10))