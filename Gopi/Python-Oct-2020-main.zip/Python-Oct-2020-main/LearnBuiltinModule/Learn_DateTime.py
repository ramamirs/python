import datetime

mydate = datetime.date.today()
print(mydate)
print(mydate.year)
print(mydate.month)
print(mydate.day)

c_date = datetime.date(2020, 1, 1)
print(c_date)