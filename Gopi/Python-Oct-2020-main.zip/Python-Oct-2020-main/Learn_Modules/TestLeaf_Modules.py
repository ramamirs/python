class TestLeaf01:

    def python(self):
        print("DEV and DS")


class TestLeaf02:

    def DevOps(self):
        print("Infra")


def Basic_info():
    print("Basic Info")

