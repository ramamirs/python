import Learn__Name__.Calculator as x

if __name__ == "__main__":
    obj = x.Cals()
    obj.add(100, 200)
    print(__name__)