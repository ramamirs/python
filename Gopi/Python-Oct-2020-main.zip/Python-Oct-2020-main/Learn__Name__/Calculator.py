class Cals:

    def add(self, a, b):
        print(a + b)


if __name__ == "__main__":
    x = Cals()
    x.add(10, 20)
    print(__name__)
